test_SXTpaste=function(){
  checkEquals(SXTpaste(c(1,2,3), sep = ""),"123")
}
