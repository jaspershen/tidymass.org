library(testthat)
library(masscleaner)
library(massdataset)
library(dplyr)
library(magrittr)

test_check("masscleaner")
